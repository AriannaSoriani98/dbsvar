# signlanguage > 2023-03-03 8:37pm
https://universe.roboflow.com/yolo-bkh56/signlanguage-hcsec

Provided by a Roboflow user
License: MIT

